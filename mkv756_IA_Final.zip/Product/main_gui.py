import tkinter as tk
from tkinter import ttk, messagebox
from database_manager import DatabaseManager
from datetime import datetime
import os
from PIL import Image, ImageTk

# Directorio de recursos para íconos e imágenes
res_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources")

class SportsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Linces Iberia - Sistema de Goleadores")
        self.root.state('zoomed') # Fullscreen en Windows
        self.root.configure(bg="white")
        self.root.bind("<Escape>", lambda event: self.root.attributes("-fullscreen", not self.root.attributes("-fullscreen"))) # Toggle FS
        
        self.res_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources")
        self.db = DatabaseManager()
        self.current_user_rol = None
        self.current_view_func = None
        self.login_logo_img = None
        self.check_icon_img = None

        self.icons = {}
        self.load_images()
        
        # Icono de la ventana (reemplaza la pluma y el logo morado)
        try:
            icon_file = os.path.join(self.res_path, "Logoiberia.png")
            if os.path.exists(icon_file):
                img = Image.open(icon_file)
                photo = ImageTk.PhotoImage(img)
                self.root.iconphoto(True, photo)
        except Exception as e:
            print(f"No se pudo cargar el icono: {e}")

        self.show_login()

    def load_images(self):
        # Cargar el logo principal de Linces desde las rutas originales
        logo_paths = [
            "topheader.png",
            "C:/Users/Estudiante.IBERIA/Downloads/topheader.png",
            "logo.png",
            "C:/Users/Estudiante.IBERIA/Downloads/unnamed.png",
            os.path.join(self.res_path, "Logoiberia.png")
        ]
        
        self.logo_img = None
        for path in logo_paths:
            if os.path.exists(path):
                try:
                    img = Image.open(path)
                    img.thumbnail((300, 150), Image.LANCZOS)
                    self.logo_img = ImageTk.PhotoImage(img)
                    break
                except Exception as e:
                    print(f"No se pudo cargar {path}: {e}")
                    
        def load_icon(name, size=(24, 24)):
            path = os.path.join(res_dir, name)
            if os.path.exists(path):
                img = Image.open(path).resize(size, Image.LANCZOS)
                return ImageTk.PhotoImage(img)
            return None

        self.icons['players'] = load_icon("players_icon.png")
        self.icons['goal'] = load_icon("goal_icon.png")
        self.icons['ranking'] = load_icon("ranking_icon.png")
        self.icons['stats'] = load_icon("stats_icon.png")
        self.icons['delete'] = load_icon("delete_icon.png", (16, 16))
        self.icons['user_welcome'] = None
        self.icons['season'] = load_icon("admin_icon.png", (24, 24))

        # Cargar logos adicionales
        try:
            login_logo_path = os.path.join(self.res_path, "Logoiberia.png")
            if os.path.exists(login_logo_path):
                img = Image.open(login_logo_path)
                img = img.resize((250, 250), Image.Resampling.LANCZOS)
                self.login_logo_img = ImageTk.PhotoImage(img)
            
            check_icon_path = os.path.join(self.res_path, "check_icon.png")
            if os.path.exists(check_icon_path):
                img = Image.open(check_icon_path)
                img = img.resize((20, 20), Image.Resampling.LANCZOS)
                self.check_icon_img = ImageTk.PhotoImage(img)
        except Exception as e:
            print(f"Error cargando logos extra: {e}")

    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def show_login(self):
        self.clear_screen()
        
        frame = tk.Frame(self.root, bg="white", pady=30)
        frame.pack(expand=True)
        
        if self.login_logo_img is not None:
            tk.Label(frame, image=self.login_logo_img, bg="white").pack(pady=10)
        elif self.logo_img:
            tk.Label(frame, image=self.logo_img, bg="white").pack(pady=10)
        
        tk.Label(frame, text="LINCES IBERIA", font=("Arial", 28, "bold"), fg="#c0392b", bg="white").pack()
        tk.Label(frame, text="Control Oficial de Goleadores", font=("Arial", 14), fg="#7f8c8d", bg="white").pack(pady=5)
        
        container = tk.LabelFrame(frame, text=" Acceso al Sistema ", bg="white", padx=30, pady=30)
        container.pack(pady=20)
        
        tk.Label(container, text="Usuario:", bg="white", font=("Arial", 10)).pack(anchor="w")
        self.ent_user = tk.Entry(container, width=35, font=("Arial", 11))
        self.ent_user.pack(pady=10)
        
        tk.Label(container, text="Contraseña:", bg="white", font=("Arial", 10)).pack(anchor="w")
        self.ent_pass = tk.Entry(container, show="*", width=35, font=("Arial", 11))
        self.ent_pass.pack(pady=10)
        
        tk.Button(container, text="INGRESAR", command=self.login, bg="#c0392b", fg="white", font=("Arial", 11, "bold"), width=25, height=2, cursor="hand2").pack(pady=20)
        
        tk.Label(frame, text="Solo Personal Autorizado - Instituto Iberia", font=("Arial", 9, "italic"), bg="white", fg="#bdc3c7").pack()
        tk.Label(frame, text="Admin: admin / 1234 | Invitado: invitado / invitado", font=("Arial", 8), bg="white", fg="#bdc3c7").pack(pady=10)

    def login(self):
        user = self.ent_user.get()
        password = self.ent_pass.get()
        rol = self.db.validar_login(user, password)
        
        if rol:
            self.current_user_rol = rol
            self.show_main_panel()
        else:
            messagebox.showerror("Error", "Credenciales incorrectas")

    def show_main_panel(self):
        self.clear_screen()
        
        # Navbar
        nav = tk.Frame(self.root, bg="#c0392b", height=70)
        nav.pack(side="top", fill="x")
        
        tk.Label(nav, text="SISTEMA LINCES IBERIA", fg="white", bg="#c0392b", font=("Arial", 16, "bold")).pack(side="left", padx=(20, 20))
        
        tk.Button(nav, text="Cerrar Sesión", command=self.show_login, bg="#962d22", fg="white", bd=0, padx=15, pady=5, font=("Arial", 10, "bold"), cursor="hand2").pack(side="right", padx=20, pady=15)

        # Filtro de Temporada Global Superior
        temporadas = self.db.obtener_temporadas()
        activa = self.db.obtener_temporada_activa()
        
        self.combo_nav_temp = ttk.Combobox(nav, values=[t['nombre'] for t in temporadas], state="readonly", width=25, font=("Arial", 10))
        if activa:
            self.combo_nav_temp.set(activa['nombre'])
        
        self.combo_nav_temp.pack(side="right", padx=5, pady=20)
        self.combo_nav_temp.bind("<<ComboboxSelected>>", self.on_temporada_change)
        
        tk.Label(nav, text="Histórico:", bg="#c0392b", fg="white", font=("Arial", 10, "bold")).pack(side="right", pady=20)

        # Menu lateral
        menu = tk.Frame(self.root, bg="#f8f9fa", width=240, bd=1, relief="flat")
        menu.pack(side="left", fill="y")
        
        lbl_menu = tk.Label(menu, text="MENÚ PRINCIPAL", bg="#f8f9fa", fg="#7f8c8d", font=("Arial", 10, "bold"), pady=20)
        lbl_menu.pack()

        def create_menu_btn(text, cmd, img_key):
            btn = tk.Button(menu, text=text, command=cmd, anchor="w", bg="#f8f9fa", bd=0, font=("Arial", 11), padx=20, pady=12, activebackground="#e9ecef", cursor="hand2", compound="left")
            if self.icons.get(img_key):
                btn.config(image=self.icons[img_key], padx=10)
            return btn

        if self.current_user_rol == "admin":
            create_menu_btn(" Gestionar Jugadores", self.view_jugadores, 'players').pack(fill="x")
            create_menu_btn(" Registrar Goles", self.view_registrar_gol, 'goal').pack(fill="x")
            create_menu_btn(" Gestión Temporadas", self.view_temporadas, 'season').pack(fill="x")
        
        create_menu_btn(" Ranking Pichichi", self.view_ranking, 'ranking').pack(fill="x")
        create_menu_btn(" Estadísticas", self.view_stats, 'stats').pack(fill="x")

        # Contenedor de contenido
        self.content_frame = tk.Frame(self.root, bg="white", padx=40, pady=40)
        self.content_frame.pack(side="right", expand=True, fill="both")
        
        self.view_ranking()

    def on_temporada_change(self, event):
        if self.current_view_func:
            self.current_view_func()

    def get_selected_temporada_id(self):
        nombre = self.combo_nav_temp.get()
        temp = self.db.obtener_temporada_por_nombre(nombre)
        return temp['id'] if temp else None

    # --- Funciones de Vistas ---
    def view_jugadores(self):
        self.current_view_func = self.view_jugadores
        self.clear_content()
        tk.Label(self.content_frame, text="GESTIÓN DE INTEGRANTES", font=("Arial", 20, "bold"), bg="white", fg="#2c3e50").pack(pady=(0, 20), anchor="w")
        
        f_add = tk.LabelFrame(self.content_frame, text=" Registrar Nuevo Lince ", bg="white", padx=20, pady=20, font=("Arial", 10, "bold"))
        f_add.pack(fill="x", pady=(0, 30))
        
        tk.Label(f_add, text="Nombre Completo:", bg="white").grid(row=0, column=0, padx=5, sticky="w")
        self.ent_nom = tk.Entry(f_add, width=32, font=("Arial", 10))
        self.ent_nom.grid(row=0, column=1, padx=10)
        
        tk.Label(f_add, text="Grado / Equipo:", bg="white").grid(row=0, column=2, padx=5, sticky="w")
        self.ent_grd = ttk.Combobox(f_add, width=18, font=("Arial", 10), state="readonly")
        self.ent_grd['values'] = [
            "1ro y 2do de Secundaria",
            "3ro y 4to de Secundaria",
            "5to y 6to de Secundaria"
        ]
        self.ent_grd.grid(row=0, column=3, padx=10)
        
        tk.Button(f_add, text="GUARDAR", command=self.add_jugador, bg="#27ae60", fg="white", font=("Arial", 10, "bold"), padx=20).grid(row=0, column=4, padx=10)

        cols = ("ID", "Nombre", "Grado / Equipo")
        self.tree_j = ttk.Treeview(self.content_frame, columns=cols, show="headings", height=10)
        for col in cols:
            self.tree_j.heading(col, text=col)
            self.tree_j.column(col, anchor="center")
        
        self.tree_j.column("ID", width=60)
        self.tree_j.column("Nombre", width=300)
        self.tree_j.pack(fill="both", expand=True)
        
        btn_del = tk.Button(self.content_frame, text=" Eliminar Lince Seleccionado", command=self.delete_jugador, bg="#e74c3c", fg="white", font=("Arial", 10, "bold"), pady=8, compound="left")
        if self.icons.get('delete'):
            btn_del.config(image=self.icons['delete'], padx=5)
        btn_del.pack(pady=20, anchor="e")
        
        self.refresh_jugadores()

    def add_jugador(self):
        nom = self.ent_nom.get().strip().title()
        grd = self.ent_grd.get().strip()
        if nom and grd:
            if self.db.jugador_existe(nom, grd):
                messagebox.showwarning("Jugador Duplicado", f"El jugador '{nom}' ya está registrado en '{grd}'.")
                return
            self.db.agregar_jugador(nom, grd)
            self.refresh_jugadores()
            self.ent_nom.delete(0, tk.END)
            self.ent_grd.set('')
            messagebox.showinfo("Éxito", "Lince registrado correctamente")
        else:
            messagebox.showwarning("Atención", "Todos los campos son obligatorios")

    def delete_jugador(self):
        selected = self.tree_j.selection()
        if not selected:
            return
        item = self.tree_j.item(selected[0])
        j_id, nombre = item['values'][0], item['values'][1]
        
        if messagebox.askyesno("Confirmar Baja", f"¿Desea eliminar a {nombre} y todos sus goles registrados?"):
            self.db.eliminar_jugador(j_id)
            self.refresh_jugadores()

    def refresh_jugadores(self):
        for i in self.tree_j.get_children():
            self.tree_j.delete(i)
        for row in self.db.obtener_jugadores():
            self.tree_j.insert("", "end", values=(row["id"], row["nombre"], row["grado"]))

    def view_registrar_gol(self):
        self.current_view_func = self.view_registrar_gol
        self.clear_content()
        tk.Label(self.content_frame, text="REGISTRO DE EFICIENCIA (GOLES)", font=("Arial", 20, "bold"), bg="white", fg="#2c3e50").pack(pady=(0, 20), anchor="w")
        
        jugadores = self.db.obtener_jugadores()
        if not jugadores:
            tk.Label(self.content_frame, text="No hay jugadores registrados en Linces Iberia.", fg="red", bg="white", font=("Arial", 12)).pack()
            return
        
        f_gol = tk.LabelFrame(self.content_frame, text=" Inserción (Se asignará a la Temporada Activa) ", bg="white", padx=30, pady=30)
        f_gol.pack(fill="x")
        
        tk.Label(f_gol, text="Seleccionar Lince Goleador:", bg="white", font=("Arial", 11)).pack(anchor="w")
        # FORMATO CON GRADO E.g. "1 - Juan - 2do de Secundaria"
        valores = [f"{j['id']} - {j['nombre']} - {j['grado']}" for j in jugadores]
        self.combo_jug = ttk.Combobox(f_gol, values=valores, width=60, font=("Arial", 11), state="readonly")
        self.combo_jug.pack(pady=(5, 20), anchor="w")
        
        f_row = tk.Frame(f_gol, bg="white")
        f_row.pack(fill="x")
        
        f_col1 = tk.Frame(f_row, bg="white")
        f_col1.pack(side="left", fill="x", expand=True)
        tk.Label(f_col1, text="Cantidad de Goles a Registrar:", bg="white", font=("Arial", 11, "bold")).pack(anchor="w")
        self.spin_qty = tk.Spinbox(f_col1, from_=1, to=20, width=15, font=("Arial", 12))
        self.spin_qty.pack(pady=(5, 10), anchor="w")
        
        btn_reg = tk.Button(f_gol, text=" REGISTRAR GOLES", command=self.save_gol, bg="#c0392b", fg="white", font=("Arial", 12, "bold"), cursor="hand2", compound="left", pady=10)
        if self.icons.get('goal'):
            btn_reg.config(image=self.icons['goal'], padx=5)
        btn_reg.pack(pady=(30, 0), fill="x", expand=True)

    def save_gol(self):
        sel = self.combo_jug.get()
        desc = "Partido Oficial"
        try:
            qty = int(self.spin_qty.get())
        except ValueError:
            qty = 1
            
        if sel:
            j_id = sel.split(" - ")[0]
            fecha = datetime.now().strftime("%Y-%m-%d")
            # Se guarda automáticamente en la temporada ACTIVA del sistema (no la del combo de vista)
            activa = self.db.obtener_temporada_activa()
            temporada_id = activa['id'] if activa else 1
            
            for _ in range(qty):
                self.db.registrar_gol(j_id, fecha, desc, temporada_id=temporada_id)
            messagebox.showinfo("¡GOOOL!", f"Se han registrado {qty} goles en la '{activa['nombre']}'.")
            self.spin_qty.delete(0, tk.END)
            self.spin_qty.insert(0, "1")
            self.view_ranking()
        else:
            messagebox.showwarning("Faltan Datos", "Seleccione un jugador para registrar los goles")

    def view_temporadas(self):
        self.current_view_func = self.view_temporadas
        self.clear_content()
        tk.Label(self.content_frame, text="ADMINISTRACIÓN DE TEMPORADAS", font=("Arial", 20, "bold"), bg="white", fg="#2c3e50").pack(pady=(0, 20), anchor="w")
        
        f_add = tk.LabelFrame(self.content_frame, text=" Crear Nueva Temporada ", bg="white", padx=20, pady=20, font=("Arial", 10, "bold"))
        f_add.pack(fill="x", pady=(0, 30))
        
        tk.Label(f_add, text="Nombre General (Ej. 2024-2025):", bg="white").grid(row=0, column=0, padx=5)
        self.ent_temp = tk.Entry(f_add, width=35, font=("Arial", 11))
        self.ent_temp.grid(row=0, column=1, padx=10)
        
        tk.Button(f_add, text="CREAR Y ACTIVAR", command=self.add_temporada, bg="#c0392b", fg="white", font=("Arial", 10, "bold")).grid(row=0, column=2, padx=10)

        cols = ("ID", "Nombre de Temporada", "Estado Activo")
        self.tree_t = ttk.Treeview(self.content_frame, columns=cols, show="headings", height=8)
        for col in cols:
            self.tree_t.heading(col, text=col)
        self.tree_t.column("ID", width=60, anchor="center")
        self.tree_t.column("Nombre de Temporada", width=350)
        self.tree_t.column("Estado Activo", width=150, anchor="center")
        self.tree_t.pack(fill="both", expand=True)

        self.refresh_temporadas()

    def add_temporada(self):
        nom = self.ent_temp.get().strip()
        if not nom:
            return
        if self.db.crear_temporada(nom):
            # Recargar el Navbar global
            temps = self.db.obtener_temporadas()
            self.combo_nav_temp['values'] = [t['nombre'] for t in temps]
            self.combo_nav_temp.set(nom)
            
            messagebox.showinfo("Éxito", f"Temporada '{nom}' creada y establecida como Activa.")
            self.ent_temp.delete(0, tk.END)
            self.refresh_temporadas()
        else:
            messagebox.showerror("Error", "Ya existe una temporada con ese nombre.")

    def refresh_temporadas(self):
        for i in self.tree_t.get_children():
            self.tree_t.delete(i)
        for t in self.db.obtener_temporadas():
            estado = "ACTIVA ✔️" if t['activa'] else "Pasada"
            self.tree_t.insert("", "end", values=(t['id'], t['nombre'], estado))

    def view_ranking(self):
        self.current_view_func = self.view_ranking
        self.clear_content()
        tk.Label(self.content_frame, text="RANKING PICHICHI - LINCES IBERIA", font=("Arial", 20, "bold"), bg="white", fg="#c0392b").pack(pady=(0, 20), anchor="w")
        
        t_id = self.get_selected_temporada_id()
        if not t_id:
            return

        tree_frame = tk.Frame(self.content_frame)
        tree_frame.pack(fill="both", expand=True)
        
        style = ttk.Style()
        style.configure("Treeview.Heading", font=("Arial", 11, "bold"))
        style.configure("Treeview", font=("Arial", 10), rowheight=30)

        tree = ttk.Treeview(tree_frame, columns=("Pos", "Nombre", "Grado / Equipo", "Goles"), show="headings")
        tree.heading("Pos", text="Posición")
        tree.heading("Nombre", text="Nombre")
        tree.heading("Grado / Equipo", text="Grado / Equipo")
        tree.heading("Goles", text="Total Goles")
        
        tree.column("Pos", width=100, anchor="center")
        tree.column("Nombre", width=350)
        tree.column("Goles", width=150, anchor="center")
        tree.pack(fill="both", expand=True)
        
        pos = 1
        for row in self.db.obtener_ranking(temporada_id=t_id):
            tag = "top" if pos <= 3 else ""
            tree.insert("", "end", values=(f"{pos}°", row["nombre"], row["grado"], row["total_goles"]), tags=(tag,))
            pos += 1
            
        tree.tag_configure("top", background="#fff5f5")

    def view_stats(self):
        self.current_view_func = self.view_stats
        self.clear_content()
        tk.Label(self.content_frame, text="PANEL DE ESTADÍSTICAS GLOBALES", font=("Arial", 20, "bold"), bg="white", fg="#2c3e50").pack(pady=(0, 20), anchor="w")
        
        t_id = self.get_selected_temporada_id()
        if not t_id:
            return
            
        stats = self.db.obtener_estadisticas(temporada_id=t_id)
        
        f_stats = tk.Frame(self.content_frame, bg="white", pady=20)
        f_stats.pack(fill="x")
        
        # Card 1: Total Goles
        c1 = tk.Frame(f_stats, bg="#fef2f2", padx=30, pady=30, bd=1, relief="flat")
        c1.pack(side="left", padx=(0, 20), fill="both", expand=True)
        tk.Label(c1, text=f"TOTAL GOLES ({self.combo_nav_temp.get()})", font=("Arial", 10, "bold"), bg="#fef2f2", fg="#991b1b").pack()
        tk.Label(c1, text=stats['total_goles'], font=("Arial", 48, "bold"), fg="#c0392b", bg="#fef2f2").pack(pady=10)
        
        # Card 2: Máximo Goleador
        c2 = tk.Frame(f_stats, bg="#fffbeb", padx=30, pady=30, bd=1, relief="flat")
        c2.pack(side="left", fill="both", expand=True)
        tk.Label(c2, text="MÁXIMO GOLEADOR (PICHICHI)", font=("Arial", 10, "bold"), bg="#fffbeb", fg="#92400e").pack()
        tk.Label(c2, text=stats['pichichi'], font=("Arial", 22, "bold"), fg="#e67e22", bg="#fffbeb").pack(pady=10)

    def clear_content(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = SportsApp(root)
    root.mainloop()

import urllib.request
import ssl
import os

ssl._create_default_https_context = ssl._create_unverified_context

icons = {
    "login_icon.png": "https://img.icons8.com/external-flaticons-lineal-color-flat-icons/96/000000/external-login-web-hosting-flaticons-lineal-color-flat-icons-2.png",
    "players_icon.png": "https://img.icons8.com/color/48/000000/people-working-together.png",
    "goal_icon.png": "https://img.icons8.com/color/48/000000/football2.png",
    "ranking_icon.png": "https://img.icons8.com/color/48/000000/trophy.png",
    "stats_icon.png": "https://img.icons8.com/color/48/000000/bar-chart.png",
    "delete_icon.png": "https://img.icons8.com/color/24/000000/trash.png",
    "admin_icon.png": "https://img.icons8.com/color/96/000000/administrative-tools.png",
    "user_welcome.png": "https://img.icons8.com/color/96/000000/verified-account.png",
    "logo_linces.png": "https://img.icons8.com/color/150/000000/year-of-tiger.png"
}

target_dir = os.path.dirname(os.path.abspath(__file__))

print(f"Downloading into {target_dir}")
for name, url in icons.items():
    print(f"Downloading {name}...")
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req) as response:
            with open(os.path.join(target_dir, name), 'wb') as out_file:
                out_file.write(response.read())
    except Exception as e:
        print(f"Error downloading {name}: {e}")

print("Done")
